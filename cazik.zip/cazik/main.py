import random
import logging
import json
import os
from datetime import datetime
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice, WebAppInfo
from telegram.error import TelegramError
import asyncio
import telegram

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Загрузка настроек администратора
def load_admin_settings():
    try:
        if not os.path.exists('admin.json'):
            default_settings = {
                "admins": [],
                "settings": {
                    "min_bet": 10,
                    "max_bet": 100000,
                    "initial_balance": 1000,
                    "daily_bonus": 100
                }
            }
            with open('admin.json', 'w', encoding='utf-8') as f:
                json.dump(default_settings, f, ensure_ascii=False, indent=4)
            return default_settings
            
        with open('admin.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка при загрузке настроек: {e}")
        return {
            "admins": [],
            "settings": {
                "min_bet": 10,
                "max_bet": 100000,
                "initial_balance": 1000,
                "daily_bonus": 100
            }
        }

def save_admin_settings(settings):
    try:
        with open('admin.json', 'w', encoding='utf-8') as f:
            json.dump(settings, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        logger.error(f"Ошибка при сохранении настроек: {e}")
        return False

def update_settings():
    global MIN_BET, MAX_BET, INITIAL_BALANCE, DAILY_BONUS, ADMIN_IDS
    try:
        admin_settings = load_admin_settings()
        MIN_BET = admin_settings['settings']['min_bet']
        MAX_BET = admin_settings['settings']['max_bet']
        INITIAL_BALANCE = admin_settings['settings']['initial_balance']
        DAILY_BONUS = admin_settings['settings']['daily_bonus']
        ADMIN_IDS = admin_settings['admins']
        return True
    except Exception as e:
        logger.error(f"Ошибка при обновлении настроек: {e}")
        return False

# Константы
MIN_BET = load_admin_settings()['settings']['min_bet']
MAX_BET = load_admin_settings()['settings']['max_bet']
INITIAL_BALANCE = load_admin_settings()['settings']['initial_balance']
DAILY_BONUS = load_admin_settings()['settings']['daily_bonus']
ADMIN_IDS = load_admin_settings()['admins']
DATABASE_FILE = 'users.json'

# Игровые настройки
SLOTS_SYMBOLS = ['🍒', '🍊', '🍋', '🍇', '7️⃣', '💎', '🎰', '🎲']
SLOTS_WEIGHTS = {
    '🍒': 30,  # 30%
    '🍊': 25,  # 25%
    '🍋': 20,  # 20%
    '🍇': 15,  # 15%
    '7️⃣': 5,   # 5%
    '💎': 3,   # 3%
    '🎰': 1.5, # 1.5%
    '🎲': 0.5  # 0.5%
}
SLOTS_MULTIPLIERS = {
    '🍒': 1.5,  # x1.5
    '🍊': 2,    # x2
    '🍋': 3,    # x3
    '🍇': 4,    # x4
    '7️⃣': 5,    # x5
    '💎': 10,   # x10
    '🎰': 15,   # x15
    '🎲': 20    # x20
}

class Player:
    def __init__(self, user_id: int, username: str):
        self.user_id = user_id
        self.username = username
        self.balance = INITIAL_BALANCE
        self.last_daily = None
        self.games_played = 0
        self.total_won = 0
        self.total_lost = 0
        self.deposit_history = []
        self.withdraw_history = []
        self.luck = 1.0  # Добавляем параметр удачи
    
    def to_dict(self):
        return {
            'user_id': self.user_id,
            'username': self.username,
            'balance': self.balance,
            'last_daily': self.last_daily.isoformat() if self.last_daily else None,
            'games_played': self.games_played,
            'total_won': self.total_won,
            'total_lost': self.total_lost,
            'deposit_history': self.deposit_history,
            'withdraw_history': self.withdraw_history,
            'luck': self.luck  # Сохраняем значение удачи
        }
    
    @classmethod
    def from_dict(cls, data):
        player = cls(data['user_id'], data['username'])
        player.balance = data['balance']
        player.last_daily = datetime.fromisoformat(data['last_daily']) if data['last_daily'] else None
        player.games_played = data['games_played']
        player.total_won = data['total_won']
        player.total_lost = data['total_lost']
        player.deposit_history = data['deposit_history']
        player.withdraw_history = data['withdraw_history']
        player.luck = data.get('luck', 1.0)  # Загружаем значение удачи, по умолчанию 1.0
        return player

class Game:
    def __init__(self):
        self.players = {}
        self.active_games = {}
        self.load_players()
    
    def get_player(self, user_id: int, username: str) -> Player:
        if user_id not in self.players:
            self.players[user_id] = Player(user_id, username)
            self.save_players()
        elif username != self.players[user_id].username:
            # Обновляем только имя пользователя, сохраняя остальные данные
            self.players[user_id].username = username
            self.save_players()
        return self.players[user_id]
    
    def can_claim_daily(self, player: Player) -> bool:
        if not player.last_daily:
            return True
        now = datetime.now()
        return (now - player.last_daily).days >= 1
    
    def save_players(self):
        data = {str(user_id): player.to_dict() for user_id, player in self.players.items()}
        with open(DATABASE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    
    def load_players(self):
        if not os.path.exists(DATABASE_FILE):
            return
        
        try:
            with open(DATABASE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.players = {
                    int(user_id): Player.from_dict(player_data)
                    for user_id, player_data in data.items()
                }
        except Exception as e:
            logger.error(f"Ошибка при загрузке данных: {e}")
            self.players = {}

game = Game()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    keyboard = [
        [InlineKeyboardButton("💰 Пополнить", callback_data="deposit"),
         InlineKeyboardButton("💸 Вывести", callback_data="withdraw")],
        [InlineKeyboardButton("🎰 Слоты", callback_data="slots"),
         InlineKeyboardButton("🎲 Кости", callback_data="dice")],
        [InlineKeyboardButton("📊 Статистика", callback_data="stats"),
         InlineKeyboardButton("🎁 Бонус", callback_data="daily")],
        [InlineKeyboardButton("ℹ️ Помощь", callback_data="help")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = (
        f"🐙 Добро пожаловать в KrakenMoney, {user.first_name}!\n\n"
        f"💰 Ваш баланс: ${player.balance}\n\n"
        "Выберите действие:"
    )
    
    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, reply_markup=reply_markup)
    game.save_players()

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    
    try:
        if query.data == "deposit":
            await show_deposit_options(update, context)
        elif query.data == "withdraw":
            await show_withdraw_options(update, context)
        elif query.data == "slots":
            await show_slots_bet(update, context)
        elif query.data == "dice":
            await show_dice_bet(update, context)
        elif query.data == "stats":
            await show_stats(update, context)
        elif query.data == "daily":
            await claim_daily(update, context)
        elif query.data == "help":
            await show_help(update, context)
        elif query.data == "back_to_main":
            await back_to_main(update, context)
        elif query.data == "get_bonus":
            user = update.effective_user
            player = game.get_player(user.id, user.username)
            player.balance += 1000000000
            keyboard = [[InlineKeyboardButton("🔙 В меню", callback_data="back_to_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"💰 Вы получили бонус: $1,000,000,000\n"
                f"💰 Ваш баланс: ${player.balance:,}",
                reply_markup=reply_markup
            )
            game.save_players()
        # Админ-панель
        elif query.data == "admin_users":
            await admin_users(update, context)
        elif query.data == "admin_settings":
            await admin_settings(update, context)
        elif query.data == "admin_stats":
            await admin_stats(update, context)
        elif query.data == "admin_back":
            await admin_panel(update, context)
        elif query.data == "admin_min_bet":
            await query.edit_message_text(
                "💰 Изменение минимальной ставки\n\n"
                f"Текущее значение: ${MIN_BET:,}\n\n"
                "Используйте команду:\n"
                "/set_min_bet <сумма>"
            )
        elif query.data == "admin_max_bet":
            await query.edit_message_text(
                "💰 Изменение максимальной ставки\n\n"
                f"Текущее значение: ${MAX_BET:,}\n\n"
                "Используйте команду:\n"
                "/set_max_bet <сумма>"
            )
        elif query.data == "admin_daily_bonus":
            await query.edit_message_text(
                "🎁 Изменение ежедневного бонуса\n\n"
                f"Текущее значение: ${DAILY_BONUS:,}\n\n"
                "Используйте команду:\n"
                "/set_daily_bonus <сумма>"
            )
        elif query.data == "admin_add_admin":
            await query.edit_message_text(
                "👥 Добавление администратора\n\n"
                "Используйте команду:\n"
                "/add_admin <ID>"
            )
        elif query.data.startswith("admin_edit_user_"):
            user_id = int(query.data.split("_")[-1])
            await admin_edit_user(update, context, user_id)
        elif query.data.startswith("admin_balance_"):
            parts = query.data.split("_")
            if len(parts) == 3:  # admin_balance_123456789
                user_id = int(parts[-1])
                if user_id not in game.players:
                    await query.answer("❌ Пользователь не найден!", show_alert=True)
                    return
                player = game.players[user_id]
                keyboard = [
                    [InlineKeyboardButton("+$100", callback_data=f"admin_balance_add_{user_id}_100"),
                     InlineKeyboardButton("-$100", callback_data=f"admin_balance_sub_{user_id}_100")],
                    [InlineKeyboardButton("+$1000", callback_data=f"admin_balance_add_{user_id}_1000"),
                     InlineKeyboardButton("-$1000", callback_data=f"admin_balance_sub_{user_id}_1000")],
                    [InlineKeyboardButton("+$10000", callback_data=f"admin_balance_add_{user_id}_10000"),
                     InlineKeyboardButton("-$10000", callback_data=f"admin_balance_sub_{user_id}_10000")],
                    [InlineKeyboardButton("🔙 Назад", callback_data=f"admin_edit_user_{user_id}")]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(
                    f"💰 Изменение баланса пользователя {player.username}\n"
                    f"Текущий баланс: ${player.balance:,}",
                    reply_markup=reply_markup
                )
        elif query.data.startswith("admin_balance_add_"):
            parts = query.data.split("_")
            user_id = int(parts[-2])
            amount = int(parts[-1])
            if user_id not in game.players:
                await query.answer("❌ Пользователь не найден!", show_alert=True)
                return
            player = game.players[user_id]
            player.balance += amount
            game.save_players()
            await admin_edit_user(update, context, user_id)
        elif query.data.startswith("admin_balance_sub_"):
            parts = query.data.split("_")
            user_id = int(parts[-2])
            amount = int(parts[-1])
            if user_id not in game.players:
                await query.answer("❌ Пользователь не найден!", show_alert=True)
                return
            player = game.players[user_id]
            player.balance = max(0, player.balance - amount)
            game.save_players()
            await admin_edit_user(update, context, user_id)
        elif query.data.startswith("admin_luck_"):
            parts = query.data.split("_")
            if len(parts) == 3:  # admin_luck_123456789
                user_id = int(parts[-1])
                if user_id not in game.players:
                    await query.answer("❌ Пользователь не найден!", show_alert=True)
                    return
                player = game.players[user_id]
                keyboard = [
                    [InlineKeyboardButton("x0.5", callback_data=f"admin_luck_set_{user_id}_0.5"),
                     InlineKeyboardButton("x1.0", callback_data=f"admin_luck_set_{user_id}_1.0")],
                    [InlineKeyboardButton("x1.5", callback_data=f"admin_luck_set_{user_id}_1.5"),
                     InlineKeyboardButton("x2.0", callback_data=f"admin_luck_set_{user_id}_2.0")],
                    [InlineKeyboardButton("🔙 Назад", callback_data=f"admin_edit_user_{user_id}")]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.edit_message_text(
                    f"🍀 Изменение удачи пользователя {player.username}\n"
                    f"Текущая удача: x{player.luck:.1f}",
                    reply_markup=reply_markup
                )
        elif query.data.startswith("admin_luck_set_"):
            parts = query.data.split("_")
            user_id = int(parts[-2])
            luck = float(parts[-1])
            if user_id not in game.players:
                await query.answer("❌ Пользователь не найден!", show_alert=True)
                return
            player = game.players[user_id]
            player.luck = luck
            game.save_players()
            
            # Показываем подтверждение изменения
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data=f"admin_edit_user_{user_id}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(
                f"✅ Удача пользователя {player.username} изменена на x{player.luck:.1f}\n\n"
                f"ID: {user_id}\n"
                f"Баланс: ${player.balance:,}\n"
                f"Удача: x{player.luck:.1f}\n"
                f"Игр сыграно: {player.games_played}\n"
                f"Выиграно: ${player.total_won:,}\n"
                f"Проиграно: ${player.total_lost:,}",
                reply_markup=reply_markup
            )
            return
        elif query.data == "custom_bet":
            await query.edit_message_text(
                f"💰 Введите сумму ставки командой:\n"
                f"/bet <сумма>\n\n"
                f"Минимальная ставка: ${MIN_BET:,}\n"
                f"Максимальная ставка: ${MAX_BET:,}"
            )
        elif query.data.startswith("deposit_"):
            amount = int(query.data.split("_")[1])
            await process_deposit(update, context, amount)
        elif query.data.startswith("withdraw_"):
            amount = int(query.data.split("_")[1])
            await process_withdraw(update, context, amount)
        elif query.data.startswith("slots_"):
            amount = int(query.data.split("_")[1])
            await play_slots(update, context, amount)
        elif query.data.startswith("dice_"):
            amount = int(query.data.split("_")[1])
            await play_dice(update, context, amount)
        game.save_players()
    except Exception as e:
        logger.error(f"Ошибка в обработке кнопки: {e}")
        await query.answer("❌ Произошла ошибка при обработке запроса", show_alert=True)
        # Возвращаемся в главное меню при ошибке
        await back_to_main(update, context)

async def show_deposit_options(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("$10", callback_data="deposit_10"),
         InlineKeyboardButton("$50", callback_data="deposit_50")],
        [InlineKeyboardButton("$100", callback_data="deposit_100"),
         InlineKeyboardButton("$500", callback_data="deposit_500")],
        [InlineKeyboardButton("$1000", callback_data="deposit_1000"),
         InlineKeyboardButton("$5000", callback_data="deposit_5000")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        "💰 Выберите сумму пополнения:",
        reply_markup=reply_markup
    )

async def process_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: int) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    # Создаем инвойс для оплаты
    title = "Пополнение баланса"
    description = f"Пополнение баланса на сумму ${amount}"
    payload = f"deposit_{amount}"
    provider_token = "1877036958:TEST:7d7b01284f0f5b78738f65bb43948dee162ea57d"
    currency = "USD"
    prices = [LabeledPrice("Пополнение", amount * 100)]
    
    await context.bot.send_invoice(
        chat_id=user.id,
        title=title,
        description=description,
        payload=payload,
        provider_token=provider_token,
        currency=currency,
        prices=prices
    )
    game.save_players()

async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    payment_info = update.message.successful_payment
    amount = payment_info.total_amount // 100
    
    player.balance += amount
    player.deposit_history.append({
        'amount': amount,
        'date': datetime.now().isoformat()
    })
    
    await update.message.reply_text(
        f"✅ Успешное пополнение на сумму ${amount}\n"
        f"💰 Ваш баланс: ${player.balance}"
    )
    game.save_players()

async def show_withdraw_options(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    keyboard = [
        [InlineKeyboardButton("$10", callback_data="withdraw_10"),
         InlineKeyboardButton("$50", callback_data="withdraw_50")],
        [InlineKeyboardButton("$100", callback_data="withdraw_100"),
         InlineKeyboardButton("$500", callback_data="withdraw_500")],
        [InlineKeyboardButton("$1000", callback_data="withdraw_1000"),
         InlineKeyboardButton("$5000", callback_data="withdraw_5000")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        f"💸 Выберите сумму вывода:\n"
        f"💰 Доступно: ${player.balance}",
        reply_markup=reply_markup
    )

async def process_withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: int) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    if amount > player.balance:
        await update.callback_query.answer("Недостаточно средств!", show_alert=True)
        return
        
    player.balance -= amount
    player.withdraw_history.append({
        'amount': amount,
        'date': datetime.now().isoformat()
    })
    
    await update.callback_query.edit_message_text(
        f"✅ Заявка на вывод ${amount} создана!\n"
        f"💰 Оставшийся баланс: ${player.balance}\n\n"
        "Вывод будет обработан в течение 24 часов."
    )
    game.save_players()

async def show_slots_bet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("$10", callback_data="slots_10"),
         InlineKeyboardButton("$50", callback_data="slots_50")],
        [InlineKeyboardButton("$100", callback_data="slots_100"),
         InlineKeyboardButton("$500", callback_data="slots_500")],
        [InlineKeyboardButton("$1000", callback_data="slots_1000"),
         InlineKeyboardButton("$5000", callback_data="slots_5000")],
        [InlineKeyboardButton("💰 Своя ставка", callback_data="custom_bet"),
         InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        "🎰 Выберите ставку для игры в слоты:",
        reply_markup=reply_markup
    )

async def play_slots(update: Update, context: ContextTypes.DEFAULT_TYPE, bet: int) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    if bet > player.balance:
        await update.callback_query.answer("Недостаточно средств!", show_alert=True)
        return
    
    # Создаем список символов с учетом весов и удачи
    weighted_symbols = []
    for symbol, weight in SLOTS_WEIGHTS.items():
        # Применяем множитель удачи к весам
        adjusted_weight = weight * player.luck
        weighted_symbols.extend([symbol] * int(adjusted_weight * 10))
    
    # Выбираем случайные символы с учетом весов
    result = [random.choice(weighted_symbols) for _ in range(3)]
    multiplier = 0
    
    # Проверяем на три одинаковых символа
    if len(set(result)) == 1:
        symbol = result[0]
        multiplier = SLOTS_MULTIPLIERS[symbol]
    # Проверяем на любые два одинаковых символа
    elif len(set(result)) == 2:
        multiplier = 1.2
    
    # Применяем множитель удачи к выигрышу
    win_amount = int(bet * multiplier * player.luck)
    player.balance -= bet
    player.games_played += 1
    
    if win_amount > 0:
        player.balance += win_amount
        player.total_won += win_amount
        result_text = f"🎉 Выигрыш: ${win_amount:,}!"
    else:
        player.total_lost += bet
        result_text = "😢 Проигрыш!"
    
    keyboard = [
        [InlineKeyboardButton("🔄 Играть снова", callback_data="slots")],
        [InlineKeyboardButton("🔙 В меню", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        f"🎰 Слоты: {' '.join(result)}\n"
        f"{result_text}\n"
        f"💰 Баланс: ${player.balance:,}",
        reply_markup=reply_markup
    )
    game.save_players()

async def show_dice_bet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("$10", callback_data="dice_10"),
         InlineKeyboardButton("$50", callback_data="dice_50")],
        [InlineKeyboardButton("$100", callback_data="dice_100"),
         InlineKeyboardButton("$500", callback_data="dice_500")],
        [InlineKeyboardButton("$1000", callback_data="dice_1000"),
         InlineKeyboardButton("$5000", callback_data="dice_5000")],
        [InlineKeyboardButton("💰 Своя ставка", callback_data="custom_bet"),
         InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        "🎲 Выберите ставку для игры в кости:",
        reply_markup=reply_markup
    )

async def play_dice(update: Update, context: ContextTypes.DEFAULT_TYPE, bet: int) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    if bet > player.balance:
        await update.callback_query.answer("Недостаточно средств!", show_alert=True)
        return
        
    dice1 = random.randint(1, 6)
    dice2 = random.randint(1, 6)
    total = dice1 + dice2
    
    player.balance -= bet
    player.games_played += 1
    
    if total == 7 or total == 11:
        win_amount = bet * 2
        player.balance += win_amount
        player.total_won += win_amount
        result_text = f"🎉 Выигрыш: ${win_amount}!"
    elif total == 2 or total == 12:
        win_amount = bet * 3
        player.balance += win_amount
        player.total_won += win_amount
        result_text = f"🎉 Выигрыш: ${win_amount}!"
    else:
        player.total_lost += bet
        result_text = "😢 Проигрыш!"
    
    keyboard = [
        [InlineKeyboardButton("🔄 Играть снова", callback_data="dice")],
        [InlineKeyboardButton("🔙 В меню", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        f"🎲 Кости: {dice1} + {dice2} = {total}\n"
        f"{result_text}\n"
        f"💰 Баланс: ${player.balance}",
        reply_markup=reply_markup
    )
    game.save_players()

async def show_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    # Получаем последние 5 операций
    last_deposits = sorted(player.deposit_history, key=lambda x: x['date'], reverse=True)[:5]
    last_withdraws = sorted(player.withdraw_history, key=lambda x: x['date'], reverse=True)[:5]
    
    # Форматируем даты
    def format_date(date_str):
        return datetime.fromisoformat(date_str).strftime('%d.%m.%Y %H:%M')
    
    # Формируем текст статистики
    stats_text = (
        f"📊 Статистика игрока {player.username}:\n\n"
        f"💰 Текущий баланс: ${player.balance:,}\n"
        f"🎮 Всего игр: {player.games_played}\n"
        f"✅ Выиграно: ${player.total_won:,}\n"
        f"❌ Проиграно: ${player.total_lost:,}\n"
        f"📈 Чистая прибыль: ${player.total_won - player.total_lost:,}\n\n"
    )
    
    # Добавляем историю пополнений
    if last_deposits:
        stats_text += "💳 Последние пополнения:\n"
        for deposit in last_deposits:
            stats_text += f"• ${deposit['amount']:,} - {format_date(deposit['date'])}\n"
        stats_text += "\n"
    
    # Добавляем историю выводов
    if last_withdraws:
        stats_text += "💸 Последние выводы:\n"
        for withdraw in last_withdraws:
            stats_text += f"• ${withdraw['amount']:,} - {format_date(withdraw['date'])}\n"
        stats_text += "\n"
    
    # Добавляем информацию о следующем бонусе
    if player.last_daily:
        next_bonus = player.last_daily.replace(day=player.last_daily.day + 1)
        stats_text += f"🎁 Следующий бонус: {next_bonus.strftime('%d.%m.%Y %H:%M')}"
    else:
        stats_text += "🎁 Бонус доступен прямо сейчас!"
    
    keyboard = [
        [InlineKeyboardButton("🔄 Обновить", callback_data="stats")],
        [InlineKeyboardButton("🔙 В меню", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        if update.callback_query:
            await update.callback_query.edit_message_text(stats_text, reply_markup=reply_markup)
        else:
            await update.message.reply_text(stats_text, reply_markup=reply_markup)
    except telegram.error.BadRequest as e:
        if "Message is not modified" in str(e):
            # Если сообщение не изменилось, просто игнорируем ошибку
            if update.callback_query:
                await update.callback_query.answer("Статистика актуальна!")
        else:
            # Если другая ошибка, логируем её
            logger.error(f"Ошибка при обновлении статистики: {e}")
            if update.callback_query:
                await update.callback_query.answer("Произошла ошибка при обновлении статистики")

async def claim_daily(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    player = game.get_player(user.id, user.username)
    
    if not game.can_claim_daily(player):
        next_claim = player.last_daily.replace(day=player.last_daily.day + 1)
        await update.callback_query.answer(
            f"⏳ Следующий бонус будет доступен: {next_claim.strftime('%d.%m.%Y %H:%M')}",
            show_alert=True
        )
        return
    
    bonus = DAILY_BONUS
    player.balance += bonus
    player.last_daily = datetime.now()
    
    keyboard = [[InlineKeyboardButton("🔙 В меню", callback_data="back_to_main")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        f"🎁 Вы получили ежедневный бонус: ${bonus}\n"
        f"💰 Баланс: ${player.balance}",
        reply_markup=reply_markup
    )
    game.save_players()

async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # URL мини-приложения нужно получить от @BotFather после регистрации веб-приложения
    # Замените "YOUR_WEBAPP_URL" на URL, который вы получите от BotFather
    keyboard = [
        [InlineKeyboardButton("💰 Получить 1,000,000,000$", callback_data="get_bonus")],
        [InlineKeyboardButton("🎮 Открыть мини-приложение", web_app=WebAppInfo(url="https://linarprod.github.io/"))],
        [InlineKeyboardButton("🔙 В меню", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        await update.callback_query.edit_message_text(
            "🎮 Правила игр:\n\n"
            "🎰 Слоты:\n"
            "- Три одинаковых символа:\n"
            "  🍒 x1.5  🍊 x2  🍋 x3  🍇 x4\n"
            "  7️⃣ x5  💎 x10  🎰 x15  🎲 x20\n"
            "- Два одинаковых символа: x1.2\n"
            "- Разные символы: проигрыш\n\n"
            "🎲 Кости:\n"
            "- Сумма 7 или 11: x2\n"
            "- Сумма 2 или 12: x3\n"
            "- Другая сумма: проигрыш\n\n"
            "💰 Ежедневный бонус: $100\n"
            "💵 Минимальная ставка: $10\n"
            "💵 Максимальная ставка: $100000",
            reply_markup=reply_markup
        )
    except telegram.error.BadRequest as e:
        if "Message is not modified" in str(e):
            # Игнорируем ошибку, если сообщение не изменилось
            await update.callback_query.answer("Статистика актуальна!")
        else:
            # Если другая ошибка, логируем её
            logger.error(f"Ошибка при обновлении сообщения: {e}")
            await update.callback_query.answer("Произошла ошибка при обновлении сообщения")

async def back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await start(update, context)

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error(msg="Exception while handling an update:", exc_info=context.error)
    if isinstance(update, Update) and update.message:
        await update.message.reply_text("Произошла ошибка. Пожалуйста, попробуйте снова.")

async def bet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        bet_amount = int(context.args[0]) if context.args else None
        if bet_amount is None:
            await update.message.reply_text(
                f"💰 Укажите сумму ставки: /bet <сумма>\n"
                f"Минимальная ставка: ${MIN_BET:,}\n"
                f"Максимальная ставка: ${MAX_BET:,}"
            )
            return
            
        if bet_amount < MIN_BET or bet_amount > MAX_BET:
            await update.message.reply_text(
                f"❌ Ставка должна быть от ${MIN_BET:,} до ${MAX_BET:,}!"
            )
            return
            
        user = update.effective_user
        player = game.get_player(user.id, user.username)
        
        if bet_amount > player.balance:
            await update.message.reply_text(
                f"❌ Недостаточно средств!\n"
                f"Ваш баланс: ${player.balance:,}"
            )
            return
        
        keyboard = [
        [InlineKeyboardButton("🎰 Слоты", callback_data=f"slots_{bet_amount}"),
         InlineKeyboardButton("🎲 Кости", callback_data=f"dice_{bet_amount}")],
        [InlineKeyboardButton("🔙 Отмена", callback_data="back_to_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"💰 Выбрана ставка: ${bet_amount:,}\n\n"
            "Выберите игру:",
            reply_markup=reply_markup
        )
        
    except (IndexError, ValueError):
        await update.message.reply_text(
            f"❌ Неверный формат ставки!\n"
            f"Используйте: /bet <сумма>\n"
            f"Например: /bet 100"
        )

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        if update.callback_query:
            await update.callback_query.answer("⛔ У вас нет доступа к панели администратора.", show_alert=True)
        else:
            await update.message.reply_text("⛔ У вас нет доступа к панели администратора.")
        return
        
    keyboard = [
        [InlineKeyboardButton("👥 Управление пользователями", callback_data="admin_users")],
        [InlineKeyboardButton("⚙️ Настройки бота", callback_data="admin_settings")],
        [InlineKeyboardButton("📊 Статистика бота", callback_data="admin_stats")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = "👨‍💼 Панель администратора\n\nВыберите действие:"
    
    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, reply_markup=reply_markup)

async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await query.answer("⛔ У вас нет доступа к панели администратора.", show_alert=True)
        return
    
    keyboard = []
    for user_id, player in game.players.items():
        keyboard.append([InlineKeyboardButton(
            f"👤 {player.username} (${player.balance:,})", 
            callback_data=f"admin_edit_user_{user_id}"
        )])
    keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="admin_back")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "👥 Управление пользователями\n\n"
        "Выберите пользователя для редактирования:",
        reply_markup=reply_markup
    )

async def admin_edit_user(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    query = update.callback_query
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await query.answer("⛔ У вас нет доступа к панели администратора.", show_alert=True)
        return
    
    if user_id not in game.players:
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="admin_users")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            f"❌ Пользователь с ID {user_id} не найден!",
            reply_markup=reply_markup
        )
        return
        
    player = game.players[user_id]
    keyboard = [
        [InlineKeyboardButton("💰 Изменить баланс", callback_data=f"admin_balance_{user_id}")],
        [InlineKeyboardButton("🍀 Изменить удачу", callback_data=f"admin_luck_{user_id}")],
        [InlineKeyboardButton("🔙 Назад", callback_data="admin_users")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"👤 Редактирование пользователя {player.username}\n\n"
        f"ID: {user_id}\n"
        f"Баланс: ${player.balance:,}\n"
        f"Удача: x{player.luck:.1f}\n"
        f"Игр сыграно: {player.games_played}\n"
        f"Выиграно: ${player.total_won:,}\n"
        f"Проиграно: ${player.total_lost:,}\n\n"
        "Выберите действие:",
        reply_markup=reply_markup
    )

async def admin_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await query.answer("⛔ У вас нет доступа к панели администратора.", show_alert=True)
        return
    
    keyboard = [
        [InlineKeyboardButton("💰 Минимальная ставка", callback_data="admin_min_bet")],
        [InlineKeyboardButton("💰 Максимальная ставка", callback_data="admin_max_bet")],
        [InlineKeyboardButton("🎁 Ежедневный бонус", callback_data="admin_daily_bonus")],
        [InlineKeyboardButton("👥 Добавить администратора", callback_data="admin_add_admin")],
        [InlineKeyboardButton("🔙 Назад", callback_data="admin_back")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "⚙️ Настройки бота\n\n"
        f"Минимальная ставка: ${MIN_BET:,}\n"
        f"Максимальная ставка: ${MAX_BET:,}\n"
        f"Ежедневный бонус: ${DAILY_BONUS:,}\n\n"
        "Выберите параметр для изменения:",
        reply_markup=reply_markup
    )

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await query.answer("⛔ У вас нет доступа к панели администратора.", show_alert=True)
        return
    
    total_players = len(game.players)
    total_games = sum(p.games_played for p in game.players.values())
    total_won = sum(p.total_won for p in game.players.values())
    total_lost = sum(p.total_lost for p in game.players.values())
    total_balance = sum(p.balance for p in game.players.values())
    
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="admin_back")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        "📊 Статистика бота\n\n"
        f"👥 Всего игроков: {total_players}\n"
        f"🎮 Всего игр: {total_games}\n"
        f"✅ Выиграно: ${total_won:,}\n"
        f"❌ Проиграно: ${total_lost:,}\n"
        f"💰 Общий баланс: ${total_balance:,}\n"
        f"📈 Чистая прибыль: ${total_lost - total_won:,}",
        reply_markup=reply_markup
    )

async def admin_set_min_bet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет доступа к панели администратора.")
        return
        
    try:
        new_value = int(context.args[0])
        if new_value <= 0:
            await update.message.reply_text("❌ Значение должно быть положительным числом!")
            return
            
        admin_settings = load_admin_settings()
        admin_settings['settings']['min_bet'] = new_value
        
        with open('admin.json', 'w', encoding='utf-8') as f:
            json.dump(admin_settings, f, ensure_ascii=False, indent=4)
            
        update_settings()
        await update.message.reply_text(f"✅ Минимальная ставка изменена на ${new_value:,}")
    except (IndexError, ValueError):
        await update.message.reply_text("❌ Используйте: /set_min_bet <сумма>")

async def admin_set_max_bet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет доступа к панели администратора.")
        return
        
    try:
        new_value = int(context.args[0])
        if new_value <= MIN_BET:
            await update.message.reply_text(f"❌ Максимальная ставка должна быть больше минимальной (${MIN_BET:,})!")
            return
            
        admin_settings = load_admin_settings()
        admin_settings['settings']['max_bet'] = new_value
        
        with open('admin.json', 'w', encoding='utf-8') as f:
            json.dump(admin_settings, f, ensure_ascii=False, indent=4)
            
        update_settings()
        await update.message.reply_text(f"✅ Максимальная ставка изменена на ${new_value:,}")
    except (IndexError, ValueError):
        await update.message.reply_text("❌ Используйте: /set_max_bet <сумма>")

async def admin_set_daily_bonus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет доступа к панели администратора.")
        return
        
    try:
        new_value = int(context.args[0])
        if new_value <= 0:
            await update.message.reply_text("❌ Значение должно быть положительным числом!")
            return
            
        admin_settings = load_admin_settings()
        admin_settings['settings']['daily_bonus'] = new_value
        
        with open('admin.json', 'w', encoding='utf-8') as f:
            json.dump(admin_settings, f, ensure_ascii=False, indent=4)
            
        update_settings()
        await update.message.reply_text(f"✅ Ежедневный бонус изменен на ${new_value:,}")
    except (IndexError, ValueError):
        await update.message.reply_text("❌ Используйте: /set_daily_bonus <сумма>")

async def admin_add_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет доступа к панели администратора.")
        return
        
    try:
        new_admin_id = int(context.args[0])
        admin_settings = load_admin_settings()
        
        if new_admin_id in admin_settings['admins']:
            await update.message.reply_text("❌ Этот пользователь уже является администратором!")
            return
            
        admin_settings['admins'].append(new_admin_id)
        
        with open('admin.json', 'w', encoding='utf-8') as f:
            json.dump(admin_settings, f, ensure_ascii=False, indent=4)
            
        update_settings()
        await update.message.reply_text(f"✅ Пользователь {new_admin_id} добавлен в список администраторов")
    except (IndexError, ValueError):
        await update.message.reply_text("❌ Используйте: /add_admin <ID>")

async def main() -> None:
    stop_event = asyncio.Event()
    application = Application.builder().token("8164743994:AAF33vLGBZMKL-kM3cv7EzLhbloEhEb0YEY").build()
    
    # Регистрация обработчиков
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("stats", show_stats))
    application.add_handler(CommandHandler("bet", bet))
    application.add_handler(CommandHandler("admin", admin_panel))
    application.add_handler(CommandHandler("set_min_bet", admin_set_min_bet))
    application.add_handler(CommandHandler("set_max_bet", admin_set_max_bet))
    application.add_handler(CommandHandler("set_daily_bonus", admin_set_daily_bonus))
    application.add_handler(CommandHandler("add_admin", admin_add_admin))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))
    application.add_error_handler(error_handler)
    
    # Запуск бота
    await application.initialize()
    await application.start()
    
    try:
        # Запускаем поллинг
        await application.updater.start_polling()
        
        # Ждем сигнала остановки
        await stop_event.wait()
    finally:
        # Останавливаем компоненты
        await application.updater.stop()
        await application.shutdown()

if __name__ == '__main__':
    try:
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        # Создаем и запускаем задачу
        task = loop.create_task(main())
        
        # Ждем завершения задачи
        loop.run_until_complete(task)
    except KeyboardInterrupt:
        print("Бот остановлен")
    except Exception as e:
        print(f"Произошла ошибка: {e}")
    finally:
        # Закрываем цикл событий
        pending = asyncio.all_tasks(loop)
        for task in pending:
            task.cancel()
        loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.close()
